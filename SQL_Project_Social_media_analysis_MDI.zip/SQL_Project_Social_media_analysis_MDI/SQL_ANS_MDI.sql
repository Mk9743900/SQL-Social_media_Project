-- Objective Questions

-- 1.	Are there any tables with duplicate or missing null values? 
SELECT * FROM comments 
WHERE 1 IS NULL OR 2 IS NULL OR 3 IS NULL OR 4 IS NULL OR 5 IS NULL ;

SELECT * FROM follows 
WHERE 1 IS NULL OR 2 IS NULL OR 3 IS NULL;

SELECT * FROM likes 
WHERE 1 IS NULL OR 2 IS NULL OR 3 IS NULL;

SELECT * FROM photo_tags
WHERE 1 IS NULL OR 2 IS NULL;

SELECT * FROM photos
WHERE 1 IS NULL OR 2 IS NULL OR 3 IS NULL OR 4 IS NULL;

SELECT * FROM tags
WHERE 1 IS NULL OR 2 IS NULL OR 3 IS NULL;

SELECT * FROM users
WHERE 1 IS NULL OR 2 IS NULL OR 3 IS NULL;

-- CHECKING DUPLICATE VALUES
 SELECT * FROM comments
 GROUP BY 1,2,3,4,5 HAVING COUNT(*) > 1;
 
  SELECT * FROM follows
 GROUP BY 1,2,3 HAVING COUNT(*) > 1;
 
  SELECT * FROM likes
 GROUP BY 1,2,3 HAVING COUNT(*) > 1;
 
  SELECT * FROM photo_tags
 GROUP BY 1,2 HAVING COUNT(*) > 1;
 
  SELECT * FROM photos
 GROUP BY 1,2,3,4 HAVING COUNT(*) > 1;
 
   SELECT * FROM tags
 GROUP BY 1,2,3 HAVING COUNT(*) > 1;
 
   SELECT * FROM users
 GROUP BY 1,2,3 HAVING COUNT(*) > 1;
-- *********************************************************************
-- 2.	What is the distribution of user activity levels (e.g., number of posts, likes, comments) across the user base?
SELECT u.id AS user_id
,username
,COUNT(DISTINCT p.id) AS photos_posted
,COUNT(DISTINCT pt.tag_id) AS tags_used
,COUNT(DISTINCT c.photo_id) AS comments_made
,COUNT(DISTINCT l.photo_id) AS likes_done
FROM users u 
LEFT JOIN photos p ON p.user_id=u.id
LEFT JOIN comments c ON c.user_id=u.id
LEFT JOIN likes l ON l.user_id=u.id
LEFT JOIN photo_tags pt ON pt.photo_id=p.id
GROUP BY 1,2;

-- *************************************************************************
-- 3.	Calculate the average number of tags per post (photo_tags and photos tables).

SELECT ROUND(COUNT(tag_id)/ COUNT(distinct photo_id),2) avg_tag_per_post 
FROM photo_tags;


-- ******************************************************************************
-- 4.	Identify the top users with the highest engagement rates (likes, comments) on their posts and rank them.

-- using CTE to find the count of likes and comments
WITH engagement AS(
SELECT u.id
	,username
	,p.id AS photo_id
	,COUNT(DISTINCT l.user_id) AS likes
	,COUNT(DISTINCT c.user_id) AS comments
FROM users u 
LEFT JOIN photos p ON u.id=p.user_id
JOIN likes l ON l.photo_id=p.id
JOIN comments c ON c.photo_id=p.id
GROUP BY 1,2,3
)

SELECT id
,username
,(likes+comments) AS total_engagement
,DENSE_RANK() OVER( ORDER BY (likes+comments) DESC) AS engagement_rank
FROM engagement;

-- *******************************************************************************************
-- 5

--  To find users with the highest number of followers and followings:
WITH follower_counts AS (
    SELECT u.id, COUNT(f.follower_id) AS follower_count
    FROM users u
    JOIN follows f ON u.id = f.followee_id
    GROUP BY u.id
),
following_counts AS (
    SELECT u.id, COUNT(f.followee_id) AS following_count
    FROM users u
	JOIN follows f ON u.id = f.follower_id
    GROUP BY u.id
)
SELECT fc.id, 
       (SELECT username FROM users WHERE id = fc.id) AS username,
       fc.follower_count, 
       fn.following_count
FROM follower_counts fc
JOIN following_counts fn ON fc.id = fn.id
ORDER BY fc.follower_count DESC, fn.following_count DESC
LIMIT 10; 
-- ****************************************************************************************************
--                   OBJECTIVE ANSWER 6
--   The average engagement rate per post for each user as follows:
SELECT
    u.id AS user_id,u.username,
    COUNT(p.id) AS total_posts,
    COALESCE(SUM(l.likes_count), 0) AS total_likes,
    COALESCE(SUM(c.comments_count), 0) AS total_comments,
    (COALESCE(SUM(l.likes_count), 0) + COALESCE(SUM(c.comments_count), 0)) / NULLIF(COUNT(p.id), 0) 
    AS avg_engagement_per_post
FROM users u
LEFT JOIN photos p ON u.id = p.user_id
JOIN (
    SELECT photo_id,COUNT(*) AS likes_count
    FROM likes
    GROUP BY photo_id) l ON p.id = l.photo_id
 JOIN (
    SELECT photo_id,COUNT(*) AS comments_count
    FROM comments
    GROUP BY photo_id) c ON p.id = c.photo_id
GROUP BY u.id, u.username
LIMIT 10;
-- ****************************************************************************************************
--                 OBJECTIVE ANSWER 7
--   Users never liked any post
with cte as (
SELECT u.id,u.username
FROM users u
WHERE u.id NOT IN (
    SELECT l.user_id
    FROM likes l)
order by u.id)
-- select * from cte
select (select count(distinct id )from users)-count(id) as Active_users , Count(id)  as Inactive_users from cte ;
-- ****************************************************************************************************
--              OBJECTIVE ANSWER 8
-- User Engagement Analysis
SELECT id AS user_id, tag_name, tags_count 
FROM (
	SELECT u.id, t.tag_name, COUNT(t.tag_name) AS tags_count,
	DENSE_RANK() OVER(PARTITION BY tag_name ORDER BY COUNT(t.tag_name) DESC) AS ranking
	FROM users u
	JOIN photos p on u.id = p.user_id
	JOIN photo_tags pt on p.id = pt.photo_id
	JOIN tags t on pt.tag_id = t.id
	GROUP BY 1, 2
) AS dt
WHERE ranking = 1;
-- ****************************************************************************************************
-- 9. Are there any correlations between user activity levels and specific content types (e.g., photos, videos, reels)? 
-- How can this information guide content creation and curation strategies?
with main as (
SELECT p.id AS photo_id, p.image_url AS photo_url,t.tag_name, COUNT(DISTINCT l.user_id) AS likes_count, COUNT(DISTINCT c.id) AS comments_count
FROM photos p
LEFT JOIN likes l on p.id = l.photo_id
LEFT JOIN comments c on p.id = c.photo_id
LEFT JOIN photo_tags pt on pt.photo_id = p.id
LEFT JOIN tags t on t.id = pt.tag_id
GROUP BY 1,2,3
ORDER BY 3 DESC)
select * from main;
select tag_name ,count(photo_id) from main group by tag_name;

-- ****************************************************************************************************
-- 10. Calculate the total number of likes, comments, and photo tags for each user.

SELECT user_id, username, SUM(likes_count) AS likes_count, SUM(comments_count) AS comments_count, SUM(tags_count) AS tags_count
FROM (
	SELECT u.id AS user_id, u.username, p.id AS photo_id, COUNT(DISTINCT l.user_id) AS likes_count, COUNT(DISTINCT c.id) AS comments_count, COUNT(DISTINCT tag_id) AS tags_count
	FROM users u 
	LEFT JOIN photos p ON u.id = p.user_id
	LEFT JOIN likes l ON p.id = l.photo_id
	LEFT JOIN comments c ON p.id = c.photo_id
	LEFT JOIN photo_tags pt ON p.id = pt.photo_id
	GROUP BY 1, 2, 3
) dt
GROUP BY 1, 2;
-- ****************************************************************************************************

-- 11. Rank users based on their total engagement (likes, comments, shares) over a month.

SELECT DATE_FORMAT(p.created_dat, '%Y-%m') AS `month`, 
u.id AS user_id, 
u.username, 
(COUNT(DISTINCT l.photo_id) + COUNT(DISTINCT c.id)) AS total_engagement,
RANK() OVER(PARTITION BY DATE_FORMAT(p.created_dat, '%Y-%m') ORDER BY (COUNT(DISTINCT l.photo_id) + COUNT(DISTINCT c.id)) DESC) AS engagement_rank
FROM users u 
LEFT JOIN photos p ON u.id = p.user_id
LEFT JOIN likes l ON u.id = l.user_id AND p.created_dat = l.created_at
LEFT JOIN comments c ON u.id = c.user_id AND p.created_dat = c.created_at
WHERE DATE_FORMAT(p.created_dat, '%Y-%m') IS NOT NULL
GROUP BY 1, 2, 3;
-- ****************************************************************************************************

-- 12. Retrieve the hashtags that have been used in posts with the highest average number of likes. Use a CTE to calculate the average likes for each hashtag first.

WITH tag_likes AS (
    SELECT t.id AS tag_id,
    tag_name,
    pt.photo_id, 
    COUNT(DISTINCT l.user_id) AS total_likes,
    AVG(COUNT(DISTINCT l.user_id)) OVER(PARTITION BY t.id) AS avg_likes
    FROM tags t 
    LEFT JOIN photo_tags pt ON t.id = pt.tag_id
    JOIN likes l ON l.photo_id = pt.photo_id
    GROUP BY 1, 2, 3
)
SELECT DISTINCT tag_id, tag_name as hashtag
FROM tag_likes
WHERE avg_likes IN (SELECT MAX(avg_likes) FROM tag_likes)
ORDER BY 1;
-- ****************************************************************************************************

-- 13. Retrieve the users who have started following someone after being followed by that person.
  SELECT 
    fb.follower_id AS user_id,
    u.username,
    fb.followee_id AS followed_back_to_user_id,
    u2.username AS followed_back_to_username,
    fa.created_at AS followed_at,
    fb.created_at AS followed_back_at
FROM follows fa  -- A follows B
JOIN follows fb  -- B follows A later
    ON fa.follower_id = fb.followee_id
    AND fa.followee_id = fb.follower_id
    AND fb.created_at > fa.created_at  -- only if B followed A after A followed B
JOIN users u ON fb.follower_id = u.id
JOIN users u2 ON fb.followee_id = u2.id
ORDER BY fb.created_at;

-- *****************************************************************************************

-- subjective
-- 1. Based on user engagement and activity levels, which users would you consider the most loyal or valuable? 
-- How would you reward or incentivize these users?

WITH cte AS (
    SELECT u.id AS user_id, 
           u.username, 
           COUNT(DISTINCT p.id) AS posts_count, 
           COUNT(DISTINCT l.photo_id) AS likes_count, 
           COUNT(DISTINCT c.id) AS comments_count,
           COUNT(DISTINCT p.id) + COUNT(DISTINCT l.photo_id) + COUNT(DISTINCT c.id) AS user_engagement, 
           DENSE_RANK() OVER(ORDER BY COUNT(DISTINCT p.id) + COUNT(DISTINCT l.photo_id) + COUNT(DISTINCT c.id) DESC) AS drank
    FROM users u 
    LEFT JOIN photos p ON u.id = p.user_id
    LEFT JOIN likes l ON u.id = l.user_id
    LEFT JOIN comments c ON u.id = c.user_id
    GROUP BY 1, 2
)
SELECT user_id, username, posts_count, likes_count, comments_count, user_engagement
FROM cte 
WHERE drank BETWEEN 1 AND 5 AND posts_count > 0;

-- ****************************************************************************************************
-- 2. For inactive users, what strategies would you recommend to re-engage them and encourage them to start posting or engaging again?

WITH cte AS (
    SELECT u.id AS user_id, 
           u.username, 
           COUNT(DISTINCT p.id) AS posts_count, 
           COUNT(DISTINCT l.photo_id) AS likes_count, 
           COUNT(DISTINCT c.id) AS comments_count,
           COUNT(DISTINCT p.id) + COUNT(DISTINCT l.photo_id) + COUNT(DISTINCT c.id) AS user_engagement, 
           DENSE_RANK() OVER(ORDER BY COUNT(DISTINCT p.id) + COUNT(DISTINCT l.photo_id) + COUNT(DISTINCT c.id)) AS drank
    FROM users u 
    LEFT JOIN photos p ON u.id = p.user_id
    LEFT JOIN likes l ON u.id = l.user_id
    LEFT JOIN comments c ON u.id = c.user_id
    GROUP BY 1, 2
)
SELECT user_id, username, posts_count, likes_count, comments_count, user_engagement
FROM cte 
WHERE drank BETWEEN 1 AND 10
ORDER BY 1;

-- ****************************************************************************************************

-- 3. Which hashtags or content topics have the highest engagement rates? How can this information guide content strategy and ad campaigns?

WITH count_likes AS (
    SELECT t.tag_name, COUNT(l.user_id) AS likes_count
    FROM tags t
    LEFT JOIN photo_tags pt ON t.id = pt.tag_id
    LEFT JOIN likes l ON pt.photo_id = l.photo_id
    GROUP BY 1
),
count_posts AS (
    SELECT t.tag_name, COUNT(p.id) AS posts_count
    FROM tags t 
    LEFT JOIN photo_tags pt ON t.id = pt.tag_id
    LEFT JOIN photos p ON pt.photo_id = p.id
    GROUP BY 1
), 
count_comments AS (
    SELECT t.tag_name, COUNT(c.id) AS comments_count
    FROM tags t 
    LEFT JOIN photo_tags pt ON t.id = pt.tag_id
    LEFT JOIN comments c ON pt.photo_id = c.photo_id
    GROUP BY 1
)
SELECT cl.tag_name, 
       cl.likes_count + cp.posts_count + cc.comments_count AS engagement,
       ROUND(
       (cl.likes_count + cp.posts_count + cc.comments_count) * 100 / 
       SUM(cl.likes_count + cp.posts_count + cc.comments_count) OVER(), 2) AS engagement_rate
FROM count_likes cl
JOIN count_posts cp ON cl.tag_name = cp.tag_name
JOIN count_comments cc ON cl.tag_name = cc.tag_name
ORDER BY 2 DESC 
LIMIT 5;
-- ****************************************************************************************************

-- 4. Are there any patterns or trends in user engagement based on demographics (age, location, gender) or posting times? 
-- How can these insights inform targeted marketing campaigns?

with cte as (
SELECT
    DAYNAME(u.created_at) AS day_of_week, 
    EXTRACT(HOUR FROM u.created_at) AS hour_of_day,       
    COUNT(DISTINCT p.id) AS total_photos_posted,         
    COUNT(DISTINCT l.user_id) AS total_likes_received,     
    COUNT(DISTINCT c.id) AS total_comments_made         
FROM users u 
LEFT JOIN photos p
	ON u.id = p.user_id
LEFT JOIN likes l
    ON p.id = l.photo_id
LEFT JOIN comments c
    ON p.id = c.photo_id
WHERE EXTRACT(HOUR FROM p.created_dat) is not null 
GROUP BY
    day_of_week,
    hour_of_day
ORDER BY
    day_of_week ,
    hour_of_day)
    
--     select * from  cte;
    
select day_of_week , sum(total_photos_posted),sum(total_likes_received),sum(total_comments_made),sum(total_photos_posted+total_likes_received+total_comments_made) as total_engagement
from cte 
GROUP BY 1;

-- 5. Based on follower counts and engagement rates, which users would be ideal candidates for influencer marketing campaigns?
-- How would you approach and collaborate with these influencers?
WITH follower_counts AS (
    SELECT followee_id AS user_id, COUNT(*) AS total_followers
    FROM follows
    GROUP BY followee_id
),
engagements AS (
    SELECT 
        p.user_id,
        COUNT(DISTINCT l.photo_id) AS likes,
        COUNT(DISTINCT c.id) AS comments
    FROM photos p
    LEFT JOIN likes l ON p.id = l.photo_id
    LEFT JOIN comments c ON p.id = c.photo_id
    GROUP BY p.user_id
)
,
user_posts AS (
    SELECT user_id, COUNT(*) AS total_posts
    FROM photos
    GROUP BY user_id
),
final AS (
    SELECT 
        u.id,
        u.username,
        COALESCE(f.total_followers, 0) AS followers,
        COALESCE(e.likes, 0) AS likes,
        COALESCE(e.comments, 0) AS comments,
        COALESCE(up.total_posts, 0) AS posts,
        ROUND((COALESCE(e.likes,0) + COALESCE(e.comments,0)) * 1.0 / NULLIF(f.total_followers, 0), 4) * 10 AS engagement_rate
    FROM users u
    LEFT JOIN follower_counts f ON u.id = f.user_id
    LEFT JOIN engagements e ON u.id = e.user_id
    LEFT JOIN user_posts up ON u.id = up.user_id
)
SELECT *
FROM final
WHERE followers >= 77 AND engagement_rate >= 30
ORDER BY engagement_rate DESC, followers DESC;

 -- 6. Based on user behavior and engagement data, how would you segment the user base for targeted marketing campaigns or personalized recommendations?

WITH user_engagement AS (
    SELECT 
        u.id AS user_id, 
        u.username, 
        COALESCE(p.engagement, 0) + COALESCE(l.engagement, 0) + COALESCE(c.engagement, 0) AS engagement,
        COALESCE(t.tag_count, 0) AS tag_count
    FROM 
        users u
    LEFT JOIN (
        SELECT user_id, COUNT(DISTINCT id) AS engagement
        FROM photos
        GROUP BY user_id
    ) p ON u.id = p.user_id
    LEFT JOIN (
        SELECT user_id, COUNT(DISTINCT photo_id) AS engagement
        FROM likes
        GROUP BY user_id
    ) l ON u.id = l.user_id
    LEFT JOIN (
        SELECT user_id, COUNT(DISTINCT id) AS engagement
        FROM comments
        GROUP BY user_id
    ) c ON u.id = c.user_id
    LEFT JOIN (
		SELECT u.id AS user_id, 
        COUNT(DISTINCT t.tag_name) AS tag_count
        FROM
        users u
    LEFT JOIN photos p ON u.id = p.user_id
    LEFT JOIN photo_tags pt ON p.id = pt.photo_id
    LEFT JOIN tags t ON pt.tag_id = t.id
    GROUP BY u.id
    ) t ON u.id = t.user_id
),
global_max AS (
    SELECT 
        MAX(engagement) AS max_engagement, 
        MAX(tag_count) AS max_tag_count
    FROM user_engagement
),
user_tags AS (
    SELECT
        u.id AS user_id,
        group_concat(t.tag_name) AS tags
    FROM
        users u
    LEFT JOIN photos p ON u.id = p.user_id
    LEFT JOIN photo_tags pt ON p.id = pt.photo_id
    LEFT JOIN tags t ON pt.tag_id = t.id
    GROUP BY u.id
),
user_segments AS (
    SELECT
        e.user_id,
        e.username,
        e.engagement,
        e.tag_count,
        t.tags,
        CASE
            WHEN e.engagement < gm.max_engagement / 3 AND e.tag_count < gm.max_tag_count / 3 THEN 'Low Engagement'
            WHEN e.engagement < 2 * gm.max_engagement / 3 AND e.tag_count < 2 * gm.max_tag_count / 3 THEN 'Moderate Engagement'
            ELSE 'High Engagement'
        END AS engagement_segment
    FROM user_engagement e
    LEFT JOIN user_tags t ON e.user_id = t.user_id
    CROSS JOIN global_max gm  -- Cross join to ensure you can use the global maximums
    GROUP BY e.user_id, e.username, e.engagement, e.tag_count, t.tags, gm.max_engagement, gm.max_tag_count
)
SELECT *
FROM user_segments
WHERE tag_count > 0 AND tags IS NOT NULL and engagement_segment in ('High Engagement', 'Low Engagement')
ORDER BY engagement_segment, engagement DESC;

